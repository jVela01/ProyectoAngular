import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Route, Router } from '@angular/router';
import { MoGrupo } from 'src/app/models/mogrupo.model';
import { SvgrupoService } from 'src/app/services/svgrupo.service';

@Component({
  selector: 'app-listgrupos',
  templateUrl: './listgrupos.component.html',
  styleUrls: ['./listgrupos.component.scss']
})
export class ListgruposComponent implements OnInit {
  lsGrupos: MoGrupo[] = [];
  public lsColumnas: string[] = ['Clave','Letra','Descripcion','Maestro','FechaAlta','Activo', 'Acciones']


  constructor(
    private svGrupos: SvgrupoService,
    private route: Router,
    private dialog:MatDialog,
    private snackBar:MatSnackBar
    ) { }

  ngOnInit(): void {
    this.cargarGrupo();
  }

  cargarGrupo(){
    this.svGrupos.get().subscribe(resp=>{
      this.lsGrupos = resp;
      console.log(this.lsGrupos)
    })
  }
  eliminar(grupos: MoGrupo){

  }
}

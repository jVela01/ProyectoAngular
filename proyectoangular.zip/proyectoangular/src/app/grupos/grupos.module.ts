import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GruposRoutingModule } from './grupos-routing.module';
import { ListgruposComponent } from './listgrupos/listgrupos.component';
import { AgregaEditaGrupoComponent } from './agrega-edita-grupo/agrega-edita-grupo.component';
import { MaterialModule } from '../shared/material/material.module';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    ListgruposComponent,
    AgregaEditaGrupoComponent
  ],
  imports: [
    CommonModule,
    GruposRoutingModule,
    MaterialModule,
    ReactiveFormsModule
  ]
})
export class GruposModule { }

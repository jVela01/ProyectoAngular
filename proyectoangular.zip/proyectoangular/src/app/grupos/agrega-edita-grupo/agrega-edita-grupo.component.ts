import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agrega-edita-grupo',
  templateUrl: './agrega-edita-grupo.component.html',
  styleUrls: ['./agrega-edita-grupo.component.scss']
})
export class AgregaEditaGrupoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AgregaEditaGrupoComponent } from './agrega-edita-grupo/agrega-edita-grupo.component';
import { ListgruposComponent } from './listgrupos/listgrupos.component';

const routes: Routes = [
  {
    path: '', component: ListgruposComponent
  },
  {
    path: ':id', component:AgregaEditaGrupoComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GruposRoutingModule { }

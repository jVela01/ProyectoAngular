export interface MoAlumno {
    nId: number,
    sNombre: string,
    sApellidos: string,
    sIdGrupo: string,
    sSexo: string,
    nEdad: number,
    sNombreTutor:string,
    sCorreoTutor: string,
    sUsuario: string,
    dFechaAlta: Date,
    bActivo: boolean
}

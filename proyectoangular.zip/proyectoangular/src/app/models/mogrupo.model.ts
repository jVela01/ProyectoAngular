export interface MoGrupo {
    sId: string,
    sLetra: string,
    sDescripcion: string,
    sUsuario: string,
    dFechaAlta: Date,
    bActivo: boolean
}

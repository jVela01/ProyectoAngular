import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MoGrupo } from '../models/mogrupo.model';

@Injectable({
  providedIn: 'root'
})
export class SvgrupoService {
  private url =environment.apiUrl;

  constructor(private http:HttpClient) { }
  get():Observable<MoGrupo[]>{
    return this.http.get<MoGrupo[]>(this.url+'grupos')
  }
  save(grupo:MoGrupo):Observable<any>{
    return this.http.post(this.url+'grupos',grupo);
  }
  getById(clave:string):Observable<MoGrupo>{
    return this.http.get<MoGrupo>(`${this.url}grupos/${clave}`);
  }
  update(clave:string, grupo:MoGrupo){
    return this.http.put(`${this.url}grupos/${clave}`,grupo);
  }
  delete(clave:string){
    return this.http.delete<MoGrupo>(`${this.url}grupos/${clave}`);
  }
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'grupos', loadChildren:()=>import('./grupos/grupos.module').then(m=>m.GruposModule)
  },
  {
    path:'', redirectTo: 'grupos', pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
